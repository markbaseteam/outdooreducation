N'est pas un sentier informatif, qui se contenterait de donner des informations passivement à des passants.

C'est un type de [[dispositif]] particulier pour l'[[éducation en extérieur]].


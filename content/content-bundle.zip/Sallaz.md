Milieu urbain, aménagé par l'homme et familier des élèves puisqu'ils le traversent fréquemment. 
Il s'agit de faire changer le regard sur la [[ville]]. L'élève sait lire son quartier, mais probablement pas avec un regard d'historien, ou de géographe, etc.

Utilisation d'une [[narration]], la nouvelle policière, pour ficeler toutes les activités ensemble.
Le lieu est toujours transdisciplinaire, pluridisciplinaire.
Tous les lieux ne parlent pas aux élèves: il faut les aider à les comprendre, à les mettre en [[mots]]

Le lieu doit être bien connu de l'enseignant pour pouvoir être exploité. Cela peut forcer le prof à mieux connaître le lieu de vie de ses élèves, de connaître leur réalité vécue.

Fouiller les spécificités du lieu à partir de détails

Certains lieux, comme la cathédrale, sont des lieux totaux, intégrant toutes les disciplines et toute la société.
> "Les faits que nous avons étudiés sont tous, qu’on nous permette l’expression, des faits sociaux totaux ou, si l’on veut — mais nous aimons moins le mot —, généraux : c’est-à-dire qu’ils mettent en branle dans certains cas la totalité de la société et de ses institutions" (Mauss, 1924)

Ces lieux sont trop massifs pour être étudiés globalement. Il faut donc partir de morceaux, de détails. On part d'un petit bout et on tire le fil à partir de là.
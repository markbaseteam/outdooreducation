

1) Faire expérimenter les lieux
2) Construire les savoirs des lieux
3) Résonnance au lieu
4) Narrations de l'expérience

Thoreau, Emerson, Dewey...
Pragmatisme ?

[[care]]
[[exigences]] 
[[sécurité]]
[[limites]]

[[parkour]]

[[citoyenneté]]

[[sens]]

[[attention]]
[[regard]]
Il faut aider les élèves à mettre en mots le lieu, les sens. Ce n'est pas une chose aisée, même pour un adulte.

Le défi est de mettre en mots le flux incessant de ce qui arrive, de
>"[...] traduire en significations disponibles un sens d’abord captif dans la chose et dans le monde même" (Merleau-Ponty, 1964)
Le dispositif doit proposer des [[activités]]
Des [[contraintes]] peuvent être utilisées pour pousser les élèves à explorer, et in fine apprendre.
L'aspect [[visuel]] est également important

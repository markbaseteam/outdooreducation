Etant pratiquant et enseignant de parkour, il y a de nombreux liens à tisser avec l'outdoor education.
En particulier, les deux pratiques transforment profondéement le regard sur le lieu.
Elles consistent à habiter temporairement un lieu d'une manière différente de la plupart des autres usagers, et une il y a une [[attention]] aux détails du lieu.
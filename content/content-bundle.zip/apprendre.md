---
alias: apprentissage, apprentissages
---

apprentissage [[incarné]]

apprentissage [[situé]]
Création complète, avec salles thématiques, photos, interviews, plan, caalogue, cafetariat...

Activités:
1) Prendre l'attention des élèves
2) Créer deux oeuvres


Les [[activités]] peuvent être organisées de manière à favoriser le mouvement des élèves. En choissant les bonnes tâches, les bonnes contraintes, les élèves sont obligés de se déplacer, p.ex. pour aller chercher des objets à des endroits différents.

L'outdoor education peut aussi permettre de changer de regard sur différents lieux, pour les relire comme lieux de mouvement, de jeu, d'activité physique. On pourrait p.ex. imaginer de demander aux élèves d'identifier plusieurs éléments du mobilier urbain, ou d'objets naturels, qui permettent d'entrainer la force: un banc pour faire des dips, un objet lourd pour du soulever de terre, etc.

Je fais ici des liens avec ma pratique et mon enseignement du [[parkour]], qui vise une telle relecture des lieux. 
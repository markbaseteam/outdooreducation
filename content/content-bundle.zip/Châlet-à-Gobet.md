Lieu forestier, mais entièrement aménagé par l'homme, et situé non loin de la ville.

Création d'un [[musée]]


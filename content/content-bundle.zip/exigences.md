Il faut que des exigences claires et relativement élevées soient communiquées aux élèves. Autrement, les élèves risquent de ne pas prendre au sérieux l'activité.
De plus, il faut des exigences si des apprentissages significatifs sont à atteindre. Il faut pouvoir évaluer les productions des élèves, afin de les retravailler en classe, etc.

Il n'est pas évident de fixer ni de vérifier ces exigences, en particulier lorsqu'elles portent sur des éléments subjectifs, comme une production artistique. Il faut donc s'efforcer de créer des critères tangibles et clairs.
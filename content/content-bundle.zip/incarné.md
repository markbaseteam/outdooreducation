On apprend également avec le corps, au travers du corps. 
Inversément, le corps est utilisé dans toutes les opérations cognitives.

Permet d'utiliser les émotions, le sensoriel, d'être au contact du monde. Complète ou vient interroger les apprentissages plus froids, analytiques, désincarnés utilisés le plus souvent à l'école.

Cela permet également d'être affecté par le lieu, et de se sentir plus facilement concerné.
Comme le dit John Haugeland un des aspects les plus importants de la différence entre un humain et une machine, est que les choses nous importent ("on ne s'en fout pas")^[https://www.youtube.com/watch?v=fcCRmf_tHW8].

On se situerait alors proche d'une éthique du [[care]]
Deux modalités:
- Capsules vidéo
- Cours en extérieur

Rendu final (15 juin)
- Création d'un [[sentier didactique]]
- Dossier de réflexion personnelle 🙋‍♂️

Numéros:
- Ismael: 079 399 10 65
- Florian: 077 427 44 30

# Lieux:
- [[HEP]]
- [[Sallaz]] (métro)
- [[Châlet-à-Gobet]] (vestiaire à côté de l'arrêt de bus)
- [[Puidoux-Gare]]
- [[Croisette]]


L'[[apprendre|apprentissage]] situé (embedded) se fait dans la même situation que celle dans lequel les compétences seront utilisées.


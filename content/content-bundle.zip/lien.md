Quel est la nature du lien que l'[[éducation en extérieur]] tente de créer entre l'élève et le lieu ?
- (s')inclure
- (s')adapter
- (se) transformer
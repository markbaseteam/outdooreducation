L'école met à distance les enfants de la cité des adultes, dans un monde à part. L'outdoor education semble être un moyen de rompre temporairement cette frontière, et de ramener les élèves dans la cité.

En donnant sens aux lieux, on peut créer du commun à plusieurs niveaux:
- établir un langage commun pour s'exprimer à propos du lieu, du ressenti, etc.
- travailler des activités communes, avec une interdépendance positive entre les élèves
- plus littéralement, construire un monde commun, en se rendant compte que les lieux sont co-construits, sont traversés par différentes logiques interdépendantes, etc.

Logique du [[care]] et de la [[durabilité]]: il faut se soucier non seulement de soi et des autres, mais également des lieux dans lesquels on vit. 
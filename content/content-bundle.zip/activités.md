Les activités ne sont pas nécessairement disciplinaires, puisque les productions peuvent être resaissies et retravaillées par différentes disciplines a posteriori.

Par exemple dessiner une carte sonore de la place de la Sallaz peut conduire à étudier:
- Changements de son dans l'histoire
- Lien entre bruit et santé
- Polution sonore
- Bruits des animaux
- Cartes et représentations spatiales
- etc.

# Maths
Maths: utiliser Thalès pour calculer la hauteur d'un arbre.

# Français
Faire la description d'un point de vue afin que quelqu'un d'autre parvienne à le retrouver.
Mettre des mots sur des objets situés à X distance d'un point, puis construire un poème avec ces mots.
Travailler une [[narration]] à partir de descriptions ou de représentations d'un lieu

# Art
Créer un land-art
Créer une palette de couleurs avec des éléments naturels
Dessiner un paysage

# Biologie
Aller chercher différents éléments d'un écosystème à partir de photos ou de descriptions

# Histoire
Décrire différents détails d'un monument, de manière à ce qu'ils puissent être retrouvés par un autre élève. Ensuite, choisir certains de ces détails pour les travailler spécifiquement.

# Travaux manuels
Construire des aménagements dans l'environnement

# EPS
Voir [[EPS]]

# Autres/pluridisciplinaire
Catégoriser des objets avec différences clés de tri.

Partir du souvenir grâce à un pont de vue surplombant, permettant de lier intérieur et extérieur. Mettre l'accent sur le fait que les lieux construisent du sens et des souvenirs.

Dessiner le paysage en rajoutant/ôtant un élément. Qu'est-ce que cela aurait changé si cet élément n'existait pas ?




En forêt: ⚠ tiques ! toujours avoir de l'antitique sur soi, prévenir les élèves/parents de s'habiller avec des vêtements longs. Matériel de prévention disponible auprès du médecin scolaire.

Délimiter des zones afin de ne pas perdre des élèves.
Il semble également préférable de toujours mettre les élèves en groupes, afin qu'ils soient responsables les uns des autres.
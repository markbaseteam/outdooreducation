Mettre du [[sens]] en organisant les éléments

Rendre l'activité transparente grâce aux spécificités du lieu, l'élève doit se dire: "ah, ici on va faire X activité"

Expliciter ce qui est attendu de l'élève, c'est à dire de se questionner. L'environnement ne parle pas tout seul.
Il s'agit d'un enseignement, et les élèves doivent donc [[apprendre]].

Il s'agit notamment de faire les tâches plusieurs fois, de manière itérative, afin d'améliorer progressivement la qualité.
Des aller-retours sont donc généralement nécessaires entre la classe et l'extérieur pour transformer les objets d'apprentissage, améliorer les expériences, etc.

Mais simplement transposer la classe dehors ne répond pas à l'[[objectif]] de l'éducation en extérieur, qui est de changer le rapport au monde.

Ne pas utiliser le lieu pour
- avec un simple support instrumental
- lieu d'aventure
- remplir des fiches
- adopter un regard moralisateur

Il faut
- réellement habiter les lieux
- donner un dispositif qui permet aux élèves de se situer.
- offrir des [[activités]] permettant de connaître le [[lieu]]
- permettre de faire des liens avec les disciplines
- mettre la [[communauté]] dans l'envirronnement